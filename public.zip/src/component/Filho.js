import React from "react";

const Filho = ({ valor, cor, callback }) => {
    const Clique = () => {
        callback(valor)
    }

    return(
        
        <div style={{ width: '100%', padding: '10px', fontSize: '16px', borderRadius: '4px', border: '1px solid #ccc' 
        }}> 
            {valor}
        </div>
        
        
    );
};
export default Filho;