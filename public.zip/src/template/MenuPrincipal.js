import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { borderRadius, Box, height } from '@mui/system';
import { Chip, Typography } from '@mui/material';



function App() {
  const [characters, setCharacters] = useState([]); 

  useEffect(() => {
    
    axios.post("https://rickandmortyapi.com/graphql", {
      query: `
        query {
          characters(page: 1) {
            results {
              id
              name
              status
              species
              image
            }
          }
        }
      `
    })
    .then(response => {
      setCharacters(response.data.data.characters.results);
    })
    .catch(error => {
      console.error("Erro ao buscar dados", error); 
    });
  }, []);

  return (
    <Box style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around' }}>
      {characters.map((character) => (
        <Box key={character.id} style={{ margin: '10px',
         width: '200px' }}>
          <img src={character.image} alt={character.name} style={{ width: '100%' }} />
          <h3>{character.name}</h3>
        
          
            <Chip 
            label = {character.status}
            sx={{
                backgroudColor: character.status === "Alive" ? 'green' : character.status ==="Dead" ? "red" : "gray",}}>
            </Chip>
          <p>Espécie: {character.species}</p>
        </Box>
        
      ))}
    </Box>
  );
}

export default App;
